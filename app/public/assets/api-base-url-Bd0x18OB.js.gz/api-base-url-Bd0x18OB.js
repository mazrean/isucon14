const a="/api";export{a};
