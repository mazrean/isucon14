const n=(t,o)=>{const c=new RegExp(`(?:^|; )${o}=([^;]*)`),e=t.match(c);return e?e[1]:void 0};export{n as g};
